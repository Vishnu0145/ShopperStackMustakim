package Utilities;

public interface IPathConstant {

	public static final  String propertiesPath="./src/main/resources/Credentials.properties";
	
	public static final  String ExcelPath="./src/main/resources/TestData.xlsx";
}
